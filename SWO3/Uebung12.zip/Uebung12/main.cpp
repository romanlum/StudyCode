#include <iostream>
#include <Vector2.h>
using namespace std;

int main()
{
    //Vector2 v2n(5e8);
    Vector2 v2(10);
    //cout << v2[5] << endl;
    //cout << v2[20] << endl;

    try {
      //Vector2 v2(5e8);
      Vector2 v2(10);
      //v2[33];
      throw "Hello world";
    } catch(Vector2::out_of_range &oor) {
      cout << "out of range" << oor.what() << endl;
    } catch(exception &e) {
      cerr << "some exception: " << e.what() << endl;
    } catch(bad_alloc &ba) {
      cerr << "heap exhausted " << ba.what() << endl;
    } catch(...) {
      cout << "caught something" << endl;
      throw;
    }


    cout << "I am still alive" << endl;
}
