#include <iostream>
#include <cassert>
#include "Queue.h"

using namespace std;

Queue::Queue(int capacity)
    :start(0), count(0), capacity(capacity), data(nullptr) {

    cout << "Queue(" << capacity << ") constructed" << endl;
    data = new Data*[capacity];
}

Queue::~Queue()
{
    delete[] data;
    cout << "~Queue(" << capacity << ") destructed" << endl;
}

bool Queue::isEmpty() const { return count == 0; }

bool Queue::isFull() const { return count == capacity; }

void Queue::enqueue(Data* item) {
    assert(!isFull());
    data[at(count)] = item;
    count ++;
}

Data *Queue::dequeue()
{
    assert(!isEmpty());
    Data* item = data[start];
    start=at(1);
    --count;
    return item;
}

ostream& operator << (ostream &os, const Queue &q) {
    os << "[";
    for(int i = 0;i < q.count; i++) {
        if( i > 0 ) os << ", ";
        os << *q.data[q.at(i)];
    }
    os << "]" << flush;
    return os;
}
