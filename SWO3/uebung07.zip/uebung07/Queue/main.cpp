#include <iostream>
#include "Queue.h"
#include "Data.h"

using namespace std;

int main()
{
    Queue q1(10);
    cout << "q1=" << q1 <<endl;
    q1.enqueue(new Data("Hallo"));
    q1.enqueue(new Data("World"));
    cout << "q1=" << q1 <<endl;
    while(!q1.isEmpty()) {
        Data* item = q1.dequeue();
        cout <<*item << endl;
        delete item;
    }
//    Queue converted = 1; o// only without explicit
    return 0;
}
