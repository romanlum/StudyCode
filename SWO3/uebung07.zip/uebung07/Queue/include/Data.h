#ifndef DATA_H
#define DATA_H

#include <string>
#include <ostream>
class Data
{
    private:
        std::string value;
    public:
        Data(std::string value);
        virtual ~Data();

        friend std::ostream& operator << (std::ostream &os, const Data &d);
    protected:

};

#endif // DATA_H
