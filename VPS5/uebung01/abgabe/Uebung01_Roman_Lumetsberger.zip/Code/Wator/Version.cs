namespace VSS.Wator
{
    public enum Version
    {
        // class names of different Wator world implementations
        // (required for selection in the settings dialog)
        DummyWatorWorld,
        OriginalWatorWorld,
    }
}