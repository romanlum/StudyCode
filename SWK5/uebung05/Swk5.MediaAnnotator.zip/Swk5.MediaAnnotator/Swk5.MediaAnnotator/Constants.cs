﻿namespace Swk5.MediaAnnotator
{
    public static class Constants
    {
        public const int MaxPreviewItems = 4;
        public static readonly string[] MediaExt = { ".gif", ".jpg" };
        public static readonly string BaseMediaFolder = @"d:\Studium\Code\SWK5\uebung05\Swk5.MediaAnnotator\Swk5.MediaAnnotator\SamplePictures\";
    }
}
