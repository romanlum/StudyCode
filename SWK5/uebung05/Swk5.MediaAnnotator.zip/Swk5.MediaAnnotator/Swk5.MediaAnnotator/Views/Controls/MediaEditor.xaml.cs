﻿using System;
using System.Windows.Controls;
using Swk5.MediaAnnotator.BL;
using Swk5.MediaAnnotator.ViewModels;

namespace Swk5.MediaAnnotator.Views.Controls
{
    /// <summary>
    /// Interaction logic for MediaEditor.xaml
    /// </summary>
    public partial class MediaEditor : UserControl
    {
        public MediaEditor()
        {
            InitializeComponent();
        }
    }
}
