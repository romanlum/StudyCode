﻿
namespace Swk5.MediaAnnotator.BL
{
    public class MediaFolder
    {
        public string Name { get; set; }
        public string Url { get; set; }
        public int ElementCount { get; set; }
    }
}
