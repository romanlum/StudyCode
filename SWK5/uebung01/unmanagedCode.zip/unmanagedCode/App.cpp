#include <cstdio>
#include "Calc.h"

int main() {

   //
   // TODO
   //

}