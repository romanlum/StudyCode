package at.lumetsnet.caas.dal;

import at.lumetsnet.caas.model.Menu;

/***
 * Menu dao
 * 
 * @author romanlum
 *
 */

public interface MenuDao extends GenericDao<Menu> {

}
