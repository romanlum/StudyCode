package at.lumetsnet.caas.dal;

import at.lumetsnet.caas.model.MenuCategory;

/***
 * MenuCategory dao
 * 
 * @author romanlum
 *
 */
public interface MenuCategoryDao extends GenericDao<MenuCategory> {

}
