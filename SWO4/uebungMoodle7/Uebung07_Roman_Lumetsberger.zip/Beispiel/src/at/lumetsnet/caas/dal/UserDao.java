package at.lumetsnet.caas.dal;

import at.lumetsnet.caas.model.User;

/***
 * User dao
 * 
 * @author romanlum
 *
 */
public interface UserDao extends GenericDao<User> {

}
