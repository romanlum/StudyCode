package at.lumetsnet.caas.rmi.impl;

/***
 * Base class for all service impls
 * 
 * @author romanlum
 *
 */
public class ServiceImpl {

	protected static final String CONNECTION_STRING = "jdbc:mysql://localhost/CaasDb";
	protected static final String USER_NAME = "root";
	protected static final String PASSWORD = null;

}
