package at.lumetsnet.swo.ue3.test;

import at.lumetsnet.swo.ue3.test.HammingTest;
import at.lumetsnet.swo.ue3.test.SortTest;

public class Main {
  
  public static void main(String[] args) {
    HammingTest.runTests();
    SortTest.runTests();
  }
}
